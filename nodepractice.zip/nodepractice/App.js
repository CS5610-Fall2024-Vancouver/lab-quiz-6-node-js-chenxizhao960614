const express = require('express');
const app = express();
const path = require('path');

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

const users = [
  { id: 1, name: 'Alice' },
  { id: 2, name: 'Bob' },
];

app.get('/users', (req, res) => {
  res.render('users', { title: 'Users List', users: users });
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
